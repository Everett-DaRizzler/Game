---Util for mathematic operations



























































































































































































---Converts the given euler yaw and pitch into a direction vector.
-- @param float yaw The yaw (y rotation) of the euler.
-- @param float pitch The pitch (x rotation) of the euler.
-- @return float x The x axis of the direction.
-- @return float y The y axis of the direction.
-- @return float z The z axis of the direction.
function MathUtil.eulerToDirection(yaw, pitch)

    -- The length of the x and y axis. When the direction is pointing straight up or down; this will be 0.
    local xzLength = math.cos(-pitch)

    -- Rotate the node around the y axis.
    return xzLength * math.sin(yaw), math.sin(-pitch), xzLength * math.cos(yaw)
end


---Calculates the pitch and yaw in radians of the given direction.
-- @param float x The x axis of the direction.
-- @param float y The y axis of the direction.
-- @param float z The z axis of the direction.
-- @return float pitch The pitch (x axis) of the rotation.
-- @return float yaw The yaw (y axis) of the rotation.
function MathUtil.directionToPitchYaw(directionX, directionY, directionZ)
    return math.asin(-directionY), math.atan2(directionX, directionZ)
end
