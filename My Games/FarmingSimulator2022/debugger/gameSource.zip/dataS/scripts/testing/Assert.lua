---A helper class for unit tests.








































































---Asserts that the given value is either nil or whose type matches the given type.
-- @param any object object whose type to check.
-- @param string expectedType The type to check the given value against.
-- @param string message The optional string mesage to be appended to the default assert message. Note that the default message includes the expected and actual values.
function Assert.isNilOrType(object, expectedType, message)
    assert(object == nil or type(object) == expectedType, string.format("%s type or nil expected: %s, actual: %s", message, expectedType, object and type(object) or "nil"))
end


---Asserts that the given object is not nil.
-- @param any actual The actual value to check.
-- @param string message The optional string mesage to be appended to the default assert message. Note that the default message includes the expected and actual values.
function Assert.isNotNil(actual, message)
    assert(actual ~= nil, string.format("%s value was nil", message))
end
