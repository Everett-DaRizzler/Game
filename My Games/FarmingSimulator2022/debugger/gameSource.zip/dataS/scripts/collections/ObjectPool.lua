---Holds a collection of pooled objects and handles creating new ones when the pool is empty.











local ObjectPool_mt = Class(ObjectPool)


---Creates a new object pool with the given constructor.
-- @param function objectConstructor The constructor function to call in order to create new objects when the pool is empty.
-- @param args ... The arguments to pass through to the constructor.
-- @return ObjectPool instance The created instance.
function ObjectPool.new(objectConstructor, ...)

    -- Ensure a constructor was given and is valid.
    --#debug assert(objectConstructor ~= nil, "Object constructor was nil.")
    --#debug assert(type(objectConstructor) == "function", "Object constructor was not a function.")

    -- Create the instance.
    local self = setmetatable({}, ObjectPool_mt)

    -- The object constructor and arguments.
    self.objectConstructor = objectConstructor
    self.objectConstructorArguments = table.pack(...)

    -- The pool of objects.
    self.pool = {}

    -- The set of pooled objects to avoid duplicates.
    self.poolSet = {}

    -- Return the created instance.
    return self
end


---Gets the total count of objects in the pool.
-- @return integer count The number of items in the pool.
function ObjectPool:getLength()
    -- TODO: Replace with __len metafunction in Lua 5.2
    return #self.pool
end


---Removes all instances from the pool's collections.
function ObjectPool:clear()
    table.clear(self.poolSet)
    table.clear(self.pool)
end


---Gets and returns an instance from the pool, or creates one if the pool is empty.
-- @return table instance The pooled or created object.
function ObjectPool:getOrCreateNext()

    -- Get the next object in the pool.
    local instance = table.remove(self.pool)

    -- If there was no object in the pool, create a new one.
    if not instance then
        instance = self.objectConstructor(table.unpack(self.objectConstructorArguments, 1, self.objectConstructorArguments.n))
    -- Otherwise; also remove the object from the set.
    else
        self.poolSet[instance] = nil
    end

    -- Return the created or gotten object.
    return instance
end


---Returns the given instance to the pool.
-- @param table instance The instance to return to the pool.
function ObjectPool:returnToPool(instance)

    -- Ensure the given instance exists.
    if instance == nil then
        return false
    end

    -- Ensure the object is not already pooled.
    if self.poolSet[instance] then
        return false
    end

    -- Call reset function if present to erase any references to external objects inside the instance
    if instance.reset ~= nil then
        instance:reset()
    end

    -- Add the object to the collections.
    table.insert(self.pool, instance)
    self.poolSet[instance] = true

    -- Return true, as the addition was a success.
    return true
end
