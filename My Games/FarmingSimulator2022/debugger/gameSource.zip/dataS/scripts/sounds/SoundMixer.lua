---This class handles the mixing of sounds depending on the game state









local SoundMixer_mt = Class(SoundMixer)


---Creating sound node
-- @return table instance instance of object
-- @return integer group audio group
function SoundMixer.new(customMt)
    local self = setmetatable({}, customMt or SoundMixer_mt)

    g_messageCenter:subscribe(MessageType.GAME_STATE_CHANGED, self.onGameStateChanged, self)

    self.masterVolume = 1

    self.gameStates = {}  -- GameState -> AudioGroup -> float volume [0..1]
    self.volumes = {}  -- AudioGroup -> float volume [0..1]
    self.volumeFactors = {}  -- AudioGroup -> float volume [0..1]
    self.volumeChangedListeners = {}  -- AudioGroup -> array {func, target}

    for _, groupIndex in pairs(AudioGroup.groups) do
        self.volumeFactors[groupIndex] = 1
        self.volumeChangedListeners[groupIndex] = {}
    end

    addConsoleCommand("gsSoundMixerDebug", "Toggle sound mixer debug mode", "consoleCommandToggleDebug", self)

    return self
end


---Load sound mixer settings from given xml filepath
-- @param string xmlFilepath filepath of the sound mixer settings xml file
function SoundMixer:loadFromXML(xmlFilepath)
    -- ensure all audio groups are initialized in case new ones were added in script
    for _, groupIndex in pairs(AudioGroup.groups) do
        self.volumeFactors[groupIndex] = self.volumeFactors[groupIndex] or 1
        self.volumeChangedListeners[groupIndex] = self.volumeChangedListeners[groupIndex] or {}
    end

    local xmlFile = loadXMLFile("soundMixerXML", xmlFilepath) -- TODO: update to new xml wrapper + schema

    if xmlFile ~= nil and xmlFile ~= 0 then

        local i = 0
        while true do
            local gameStateKey = string.format("soundMixer.gameState(%d)", i)
            if not hasXMLProperty(xmlFile, gameStateKey) then
                break
            end

            local gameStateName = getXMLString(xmlFile, gameStateKey.."#name")
            local gameStateIndex = g_gameStateManager:getGameStateIndexByName(gameStateName)
            if gameStateIndex ~= nil then
                local gameState = {}

                local j = 0
                while true do
                    local audioGroupKey = string.format("%s.audioGroup(%d)", gameStateKey, j)
                    if not hasXMLProperty(xmlFile, audioGroupKey) then
                        break
                    end

                    local name = getXMLString(xmlFile, audioGroupKey.."#name")
                    local volume = getXMLFloat(xmlFile, audioGroupKey.."#volume") or 1.0
                    local audioGroupIndex = AudioGroup.getAudioGroupIndexByName(name)

                    if audioGroupIndex ~= nil then
                        gameState[audioGroupIndex] = volume
                    else
                        Logging.xmlWarning(xmlFile, "Audio-Group '%s' in game state '%s' (%s) is not defined!", name, gameStateName, gameStateKey)
                    end

                    j = j + 1
                end

                self.gameStates[gameStateIndex] = gameState
            else
                Logging.xmlWarning(xmlFile, "Game-State '%s' is not defined for state '%s'!", gameStateName, gameStateKey)
            end

            i = i + 1
        end

        delete(xmlFile)
    end

    -- initialize self.volumes for all AudioGroups
    local currentGameState = g_gameStateManager:getGameState()
    local gameStateAudioGroups = self.gameStates[currentGameState] or self.gameStates[GameState.LOADING]  -- current game state might not be included in mixer config

    for _, groupIndex in ipairs(AudioGroup.groups) do
        local volume = (gameStateAudioGroups and gameStateAudioGroups[groupIndex]) or 1
        self.volumes[groupIndex] = volume
        setAudioGroupVolume(groupIndex, volume)
    end
end


---
function SoundMixer:delete()
    g_messageCenter:unsubscribeAll(self)

    removeConsoleCommand("gsSoundMixerDebug")
end


---
function SoundMixer:update(dt)
    if self.isDirty then
        local gameStateIndex = g_gameStateManager:getGameState()
        local gameState = self.gameStates[gameStateIndex]
        if gameState ~= nil then
            local isDone = true
            for audioGroupIndex, audioGroupVolume in pairs(gameState) do
                local currentVolume = self.volumes[audioGroupIndex]
                local target = audioGroupVolume * self.volumeFactors[audioGroupIndex]
                if currentVolume ~= target then
                    isDone = false

                    local dir = 1
                    local func = math.min
                    if currentVolume > target then
                        dir = -1
                        func = math.max
                    end

                    currentVolume = func(currentVolume + dir * dt/500, target)
                    setAudioGroupVolume(audioGroupIndex, currentVolume)
                    self.volumes[audioGroupIndex] = currentVolume
                    for _, listener in ipairs(self.volumeChangedListeners[audioGroupIndex]) do
                        listener.func(listener.target, audioGroupIndex, currentVolume)
                    end
                end
            end

            if isDone then
                self.isDirty = false
            end
        end
    end
end








































---
function SoundMixer:setAudioGroupVolumeFactor(audioGroupIndex, factor)
    if audioGroupIndex ~= nil and self.volumeFactors[audioGroupIndex] ~= nil then
        self.volumeFactors[audioGroupIndex] = factor
        self.isDirty = true
    end
end


---
function SoundMixer:setMasterVolume(masterVolume)
    self.masterVolume = masterVolume
    setMasterVolume(masterVolume)
end


---
function SoundMixer:onGameStateChanged(gameStateId, oldGameState)
    local gameState = self.gameStates[gameStateId]
    if gameState ~= nil then
        self.isDirty = true
--#debug     else
--#debug         Logging.warning("No sound mixing settings for game state %s", gameStateId)
    end
end


---
function SoundMixer:addVolumeChangedListener(audioGroupIndex, func, target)
    if self.volumeChangedListeners[audioGroupIndex] == nil then
        self.volumeChangedListeners[audioGroupIndex] = {}
    end

    -- TODO: this will not prevent duplicates, use target as key instead?
    table.addElement(self.volumeChangedListeners[audioGroupIndex], {func=func, target=target})
end
