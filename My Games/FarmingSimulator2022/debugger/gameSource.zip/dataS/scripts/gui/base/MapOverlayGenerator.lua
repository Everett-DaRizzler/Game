---Generator
--Provides density map based data overlays on top of an in-game map.








local MapOverlayGenerator_mt = Class(MapOverlayGenerator)

























---Create a MapOverlayGenerator instance.
-- @param table l10n I18N reference for text localization
-- @param table fruitTypeManager FruitTypeManager reference for fruit type resolution
-- @param table fillTypeManager FillTypeManager reference for fruit fill type resolution
-- @param table farmlandManager FarmlandManager reference for farm land data access
-- @param table farmManager FarmManager reference for farm land ownership data access
function MapOverlayGenerator.new(l10n, fruitTypeManager, fillTypeManager, farmlandManager, farmManager, weedSystem)
    local self = setmetatable({}, MapOverlayGenerator_mt)

    self.l10n = l10n
    self.fruitTypeManager = fruitTypeManager
    self.fillTypeManager = fillTypeManager
    self.farmlandManager = farmlandManager
    self.farmManager = farmManager

    self.missionFruitTypes = {}
    self.isColorBlindMode = nil

    self.foliageStateOverlay = createDensityMapVisualizationOverlay("foliageState", unpack(self:adjustedOverlayResolution(MapOverlayGenerator.OVERLAY_RESOLUTION.FOLIAGE_STATE)))
    self.farmlandStateOverlay = createDensityMapVisualizationOverlay("farmlandState", unpack(self:adjustedOverlayResolution(MapOverlayGenerator.OVERLAY_RESOLUTION.FARMLANDS, true)))
    self.minimapOverlay = createDensityMapVisualizationOverlay("minimap", unpack(self:adjustedOverlayResolution(MapOverlayGenerator.OVERLAY_RESOLUTION.MINIMAP)))

    self.typeBuilderFunctionMap = {
        [MapOverlayGenerator.OVERLAY_TYPE.CROPS] = self.buildFruitTypeMapOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.GROWTH] = self.buildGrowthStateMapOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.SOIL] = self.buildSoilStateMapOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.FARMLANDS] = self.buildFarmlandsMapOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.MINIMAP] = self.buildMinimapOverlay,
    }

    self.overlayHandles = {
        [MapOverlayGenerator.OVERLAY_TYPE.CROPS] = self.foliageStateOverlay, -- re-use this handle, these types are mutually exclusive
        [MapOverlayGenerator.OVERLAY_TYPE.GROWTH] = self.foliageStateOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.SOIL] = self.foliageStateOverlay,
        [MapOverlayGenerator.OVERLAY_TYPE.FARMLANDS] = self.farmlandStateOverlay, -- farmlands are separate
        [MapOverlayGenerator.OVERLAY_TYPE.MINIMAP] = self.minimapOverlay, -- farmlands are separate
    }

    self.currentOverlayHandle = nil -- handle of overlay which is currently being generated or nil if none is processing
    self.overlayFinishedCallback = NO_CALLBACK

    self.overlayTypeCheckHash = {}
    for k, v in pairs(MapOverlayGenerator.OVERLAY_TYPE) do
        self.overlayTypeCheckHash[v] = k
    end

    self.fieldColor = MapOverlayGenerator.FIELD_COLOR
    self.grassFieldColor = MapOverlayGenerator.FIELD_GRASS_COLOR

    -- Set overlay refresh time limit... block less long in console single- and console/PC MP server mode
    if GS_IS_CONSOLE_VERSION or (g_currentMission.missionDynamicInfo.isMultiplayer and g_currentMission:getIsServer()) then
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.foliageStateOverlay, 10)
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.farmlandStateOverlay, 10)
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.minimapOverlay, 10)
    else
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.foliageStateOverlay, 20)
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.farmlandStateOverlay, 20)
        setDensityMapVisualizationOverlayUpdateTimeLimit(self.minimapOverlay, 20)
    end

    return self
end


---Delete this instance and any used overlays.
function MapOverlayGenerator:delete()
    self:reset()
    delete(self.foliageStateOverlay)
    delete(self.farmlandStateOverlay)
    delete(self.minimapOverlay)
end


---Update the map resolution depending on machine quality (settings)
function MapOverlayGenerator:adjustedOverlayResolution(default, limitToTwo)
    local profileClass = Utils.getPerformanceClassId()

    if profileClass == GS_PROFILE_LOW then
        return default

    -- Do not go too big ons ervers to keep latency low within the engine; also avoid high memory use on consoles & mobile
    elseif profileClass >= GS_PROFILE_VERY_HIGH and not limitToTwo and not GS_IS_CONSOLE_VERSION and not GS_IS_MOBILE_VERSION and not (g_currentMission.missionDynamicInfo.isMultiplayer and g_currentMission:getIsServer()) then
        return {default[1] * 4, default[2] * 4}
    else
        return {default[1] * 2, default[2] * 2}
    end
end


---Set the valid fruit types of the current mission.
function MapOverlayGenerator:setMissionFruitTypes(missionFruitTypes)
    self.missionFruitTypes = {}
    for _, fruitType in ipairs(missionFruitTypes) do
        -- transfer to new data structure used to display filters:
        table.insert(self.missionFruitTypes, {
            foliageId = fruitType.terrainDataPlaneId,
            fruitTypeIndex = fruitType.index,
            shownOnMap = fruitType.shownOnMap,
            defaultColor = fruitType.defaultMapColor,
            colorBlindColor = fruitType.colorBlindMapColor
        })
    end

    self.displayCropTypes = self:getDisplayCropTypes()
    self.displayGrowthStates = self:getDisplayGrowthStates()
    self.displaySoilStates = self:getDisplaySoilStates()
end








---Set the color blind mode for overlay creation.
function MapOverlayGenerator:setColorBlindMode(isColorBlindMode)
    self.isColorBlindMode = isColorBlindMode
end







---Build the map overlay for fruit types.
function MapOverlayGenerator:buildFruitTypeMapOverlay(fruitTypeFilter)
    for _, displayCropType in ipairs(self.displayCropTypes) do
        if fruitTypeFilter[displayCropType.fruitTypeIndex] then
            local foliageId = displayCropType.foliageId
            if foliageId ~= nil and foliageId ~= 0 then
                setDensityMapVisualizationOverlayTypeColor(self.foliageStateOverlay, foliageId, unpack(displayCropType.colors[self.isColorBlindMode]))
            end
        end
    end
end


---Build the map overlay for minimap
function MapOverlayGenerator:buildMinimapOverlay(fruitTypeFilter)
    self:buildFieldMapOverlay(self.minimapOverlay)
end


---Build the map overlay for growth states.
function MapOverlayGenerator:buildGrowthStateMapOverlay(growthStateFilter, fruitTypeFilter)
    for _, displayCropType in ipairs(self.displayCropTypes) do
        if fruitTypeFilter[displayCropType.fruitTypeIndex] then
            local foliageId = displayCropType.foliageId
            local desc = self.fruitTypeManager:getFruitTypeByIndex(displayCropType.fruitTypeIndex)

            if desc.maxHarvestingGrowthState >= 0 then
                if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.WITHERED] then
                    if desc.witheredState ~= nil then
                        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.WITHERED].colors[self.isColorBlindMode][1]
                        setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, foliageId, desc.witheredState, color[1], color[2], color[3])
                    end
                end

                if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.HARVESTED] then
                    local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.HARVESTED].colors[self.isColorBlindMode][1]
                    setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, foliageId, desc.cutState, color[1], color[2], color[3])
                end

                if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.GROWING] then
                    local maxGrowingState = desc.minHarvestingGrowthState - 1
                    if desc.minPreparingGrowthState >= 0 then
                        maxGrowingState = math.min(maxGrowingState, desc.minPreparingGrowthState - 1)
                    end

                    local colors = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.GROWING].colors[self.isColorBlindMode]
                    for i = 1, maxGrowingState do
                        -- Spready states across colors as different fruits have a different number of growth states
                        local index = math.max(math.floor(#colors / maxGrowingState * i), 1)
                        setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, foliageId, i, colors[index][1], colors[index][2], colors[index][3])
                    end
                end

                if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.TOPPING] then
                    if desc.minPreparingGrowthState >= 0 then
                        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.TOPPING].colors[self.isColorBlindMode][1]
                        for i = desc.minPreparingGrowthState, desc.maxPreparingGrowthState do
                            setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, foliageId, i, color[1], color[2], color[3])
                        end
                    end
                end

                if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.HARVEST] then
                    local colors = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.HARVEST].colors[self.isColorBlindMode]
                    for i = desc.minHarvestingGrowthState, desc.maxHarvestingGrowthState do
                        local index = math.min(i - desc.minHarvestingGrowthState + 1, #colors)
                        setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, foliageId, i, colors[index][1], colors[index][2], colors[index][3])
                    end
                end
            end
        end
    end

    local mission = g_currentMission
    local groundTypeMapId, groundTypeFirstChannel, groundTypeNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)

    -- local fieldMask = 15
    local fieldMask = bitShiftLeft(bitShiftLeft(1, groundTypeNumChannels)-1, groundTypeFirstChannel)
    if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.CULTIVATED] then
        local cultivatorValue = mission.fieldGroundSystem:getFieldGroundValue(FieldGroundType.CULTIVATED)
        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.CULTIVATED].colors[self.isColorBlindMode][1]
        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, groundTypeMapId, 0, fieldMask, groundTypeFirstChannel, groundTypeNumChannels, cultivatorValue, color[1], color[2], color[3])
    end

    if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.PLOWED] then
        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.PLOWED].colors[self.isColorBlindMode][1]
        local plowValue = mission.fieldGroundSystem:getFieldGroundValue(FieldGroundType.PLOWED)
        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, groundTypeMapId, 0, fieldMask, groundTypeFirstChannel, groundTypeNumChannels, plowValue, color[1], color[2], color[3])
    end

    if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.STUBBLE_TILLAGE] then
        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.STUBBLE_TILLAGE].colors[self.isColorBlindMode][1]
        local stubbleTillageValue = mission.fieldGroundSystem:getFieldGroundValue(FieldGroundType.STUBBLE_TILLAGE)
        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, groundTypeMapId, 0, fieldMask, groundTypeFirstChannel, groundTypeNumChannels, stubbleTillageValue, color[1], color[2], color[3])
    end

    if growthStateFilter[MapOverlayGenerator.GROWTH_STATE_INDEX.SEEDBED] then
        local color = self.displayGrowthStates[MapOverlayGenerator.GROWTH_STATE_INDEX.SEEDBED].colors[self.isColorBlindMode][1]
        local seedBedValue = mission.fieldGroundSystem:getFieldGroundValue(FieldGroundType.SEEDBED)
        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, groundTypeMapId, 0, fieldMask, groundTypeFirstChannel, groundTypeNumChannels, seedBedValue, color[1], color[2], color[3])
        local rolledSeedBedValue = mission.fieldGroundSystem:getFieldGroundValue(FieldGroundType.ROLLED_SEEDBED)
        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, groundTypeMapId, 0, fieldMask, groundTypeFirstChannel, groundTypeNumChannels, rolledSeedBedValue, color[1], color[2], color[3])
    end
end


---Build the map overlay for soil states.
function MapOverlayGenerator:buildSoilStateMapOverlay(soilStateFilter)
    local mission = g_currentMission
    local groundTypeMapId, groundTypeFirstChannel, groundTypeNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.GROUND_TYPE)
    -- local fieldMask = 15
    local fieldMask = bitShiftLeft(bitShiftLeft(1, groundTypeNumChannels)-1, groundTypeFirstChannel)

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.WEEDS] and mission.missionInfo.weedsEnabled then
        local weedSystem = mission.weedSystem
        if weedSystem ~= nil and weedSystem:getMapHasWeed() then
            local weedMapId, _, _ = weedSystem:getDensityMapData()

            local mapColor, mapColorBlind = weedSystem:getColors()
            local colors = self.isColorBlindMode and mapColorBlind or mapColor

            for k, data in ipairs(colors) do
                local stateColor = data.color
                for _, state in ipairs(data.states) do
                    setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, weedMapId, state, stateColor[1], stateColor[2], stateColor[3])
                end
            end
        end
    end

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.STONES] and mission.missionInfo.stonesEnabled then
        local stoneSystem = mission.stoneSystem
        if stoneSystem ~= nil and stoneSystem:getMapHasStones() then
            local stoneMapId, _, _ = stoneSystem:getDensityMapData()

            local mapColor, mapColorBlind = stoneSystem:getColors()
            local colors = self.isColorBlindMode and mapColorBlind or mapColor

            for k, data in ipairs(colors) do
                local stateColor = data.color
                for _, state in ipairs(data.states) do
                    setDensityMapVisualizationOverlayGrowthStateColor(self.foliageStateOverlay, stoneMapId, state, stateColor[1], stateColor[2], stateColor[3])
                end
            end
        end
    end

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_PLOWING] and mission.missionInfo.plowingRequiredEnabled then
        local color = self.displaySoilStates[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_PLOWING].colors[self.isColorBlindMode][1]
        local mapId, plowLevelFirstChannel, plowLevelNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.PLOW_LEVEL)

        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, mapId, groundTypeMapId, fieldMask, plowLevelFirstChannel, plowLevelNumChannels, 0, color[1], color[2], color[3])
    end

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_ROLLING] then
        local color = self.displaySoilStates[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_ROLLING].colors[self.isColorBlindMode][1]
        local mapId, rollerLevelFirstChannel, rollerLevelNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.ROLLER_LEVEL)

        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, mapId, 0, fieldMask, rollerLevelFirstChannel, rollerLevelNumChannels, 1, color[1], color[2], color[3])
    end

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.MULCHED] then
        local color = self.displaySoilStates[MapOverlayGenerator.SOIL_STATE_INDEX.MULCHED].colors[self.isColorBlindMode][1]
        local mapId, mulchFirstChannel, mulchNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.STUBBLE_SHRED)

        setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, mapId, 0, fieldMask, mulchFirstChannel, mulchNumChannels, 1, color[1], color[2], color[3])
    end

    if not GS_IS_MOBILE_VERSION then
        if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_LIME] and mission.missionInfo.limeRequired then
            local color = self.displaySoilStates[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_LIME].colors[self.isColorBlindMode][1]
            local mapId, limeLevelFirstChannel, limeLevelNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.LIME_LEVEL)

            setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, mapId, groundTypeMapId, fieldMask, limeLevelFirstChannel, limeLevelNumChannels, 0, color[1], color[2], color[3])
        end
    end

    if soilStateFilter[MapOverlayGenerator.SOIL_STATE_INDEX.FERTILIZED] then
        local colors = self.displaySoilStates[MapOverlayGenerator.SOIL_STATE_INDEX.FERTILIZED].colors[self.isColorBlindMode]
        local sprayMapId, sprayLevelFirstChannel, sprayLevelNumChannels = mission.fieldGroundSystem:getDensityMapData(FieldDensityMap.SPRAY_LEVEL)
        local maxSprayLevel = mission.fieldGroundSystem:getMaxValue(FieldDensityMap.SPRAY_LEVEL)
        for level = 1, maxSprayLevel do
            local color = colors[math.min(level, #colors)]
            setDensityMapVisualizationOverlayStateColor(self.foliageStateOverlay, sprayMapId, 0, fieldMask, sprayLevelFirstChannel, sprayLevelNumChannels, level, color[1], color[2], color[3])
        end
    end
end





















---Build the map overlay for farm lands.
function MapOverlayGenerator:buildFarmlandsMapOverlay(selectedFarmland)
    local map = self.farmlandManager:getLocalMap()
    local farmlands = self.farmlandManager:getFarmlands()

    setOverlayColor(self.farmlandStateOverlay, 1, 1, 1, MapOverlayGenerator.FARMLANDS_ALPHA)

    for k, farmland in pairs(farmlands) do
        local ownerFarmId = self.farmlandManager:getFarmlandOwner(farmland.id)

        if ownerFarmId ~= FarmlandManager.NOT_BUYABLE_FARM_ID then
            if selectedFarmland ~= nil and farmland.id == selectedFarmland.id then
                setDensityMapVisualizationOverlayStateColor(self.farmlandStateOverlay, map, 0, 0, 0, getBitVectorMapNumChannels(map), k, unpack(MapOverlayGenerator.COLOR.FIELD_SELECTED))
            else
                local color = MapOverlayGenerator.COLOR.FIELD_UNOWNED
                if farmland.isOwned then -- assign farm color
                    local ownerFarm = self.farmManager:getFarmById(ownerFarmId)
                    if ownerFarm ~= nil then
                        color = ownerFarm:getColor()
                    end
                end

                setDensityMapVisualizationOverlayStateColor(self.farmlandStateOverlay, map, 0, 0, 0, getBitVectorMapNumChannels(map), k, unpack(color))
            end
        end
    end

    -- No borders on small maps
    local profileClass = Utils.getPerformanceClassId()
    if profileClass >= GS_PROFILE_HIGH then
        setDensityMapVisualizationOverlayStateBorderColor(self.farmlandStateOverlay, map, 0, getBitVectorMapNumChannels(map), MapOverlayGenerator.FARMLANDS_BORDER_THICKNESS, unpack(MapOverlayGenerator.COLOR.FIELD_BORDER))
    end

    self:buildFieldMapOverlay(self.farmlandStateOverlay)
end


---Generate a map overlay of a given type.
This is an internal generic interfacing method and should not be called externally. Consumers should use one of the
specific public methods instead, e.g. MapOverlayGenerator:generateFruitTypeOverlay().
-- @param int mapOverlayType Overlay type as one of MapOverlayGenerator.OVERLAY_TYPE.[CROPS|GROWTH|SOIL|FARMLANDS]
-- @param function finishedCallback Function which is called with the overlay ID as its argument when processing is
finished, signature: function(overlayId)
-- @param table overlayState Overlay state data which defines parameters (e.g. colors) of the map overlays.
-- @return bool True if overlay generation has started, false if generation is already in progress or an invalid overlay
type has been provided
function MapOverlayGenerator:generateOverlay(mapOverlayType, finishedCallback, overlayState, overlayState2)
    local success = true
    if self.overlayTypeCheckHash[mapOverlayType] == nil then
        Logging.warning("Tried generating a map overlay with an invalid overlay type: [%s]", tostring(mapOverlayType))
        success = false
    else
        local overlayHandle = self.overlayHandles[mapOverlayType]
        self.overlayFinishedCallback = finishedCallback or NO_CALLBACK
        resetDensityMapVisualizationOverlay(overlayHandle) -- clear any previous overlay state

        self.currentOverlayHandle = overlayHandle

        local builderFunction = self.typeBuilderFunctionMap[mapOverlayType]

        builderFunction(self, overlayState, overlayState2)

        -- generate the map overlay based on the settings made in the build methods
        generateDensityMapVisualizationOverlay(overlayHandle)
        self:checkOverlayFinished() -- check now, might already be done
    end

    return success
end


---Generate a fruit type overlay.
-- @param function finishedCallback Called when generation is finished, signature: function(overlayId)
-- @param table fruitTypeFilter Map of fruit type indices to booleans. If the value is true, the fruit type will be displayed.
-- @return bool True if overlay generation has started, false if generation is already in progress or an invalid overlay
type has been provided
function MapOverlayGenerator:generateFruitTypeOverlay(finishedCallback, fruitTypeFilter)
    return self:generateOverlay(MapOverlayGenerator.OVERLAY_TYPE.CROPS, finishedCallback, fruitTypeFilter)
end


---Generate ovrlay for minimap
-- @param function finishedCallback Called when generation is finished, signature: function(overlayId)
-- @param table fruitTypeFilter Map of fruit type indices to booleans. If the value is true, the fruit type will be displayed.
-- @return bool True if overlay generation has started, false if generation is already in progress or an invalid overlay
type has been provided
function MapOverlayGenerator:generateMinimapOverlay(finishedCallback, fruitTypeFilter)
    return self:generateOverlay(MapOverlayGenerator.OVERLAY_TYPE.MINIMAP, finishedCallback, fruitTypeFilter)
end


---Generate a growth state overlay.
-- @param function finishedCallback Called when generation is finished, signature: function(overlayId)
-- @param table fruitTypeFilter Map of growth state indices (MapOverlayGenerator.GROWTH_STATE_INDEX members) to
booleans. If the value is true, the growth state will be displayed.
-- @return bool True if overlay generation has started, false if generation is already in progress or an invalid overlay
type has been provided
function MapOverlayGenerator:generateGrowthStateOverlay(finishedCallback, growthStateFilter, fruitTypeFilter)
    return self:generateOverlay(MapOverlayGenerator.OVERLAY_TYPE.GROWTH, finishedCallback, growthStateFilter, fruitTypeFilter)
end


---Generate a soil state overlay.
-- @param function finishedCallback Called when generation is finished, signature: function(overlayId)
-- @param table fruitTypeFilter Map of soil state indices (MapOverlayGenerator.SOIL_STATE_INDEX members) to
booleans. If the value is true, the soil state will be displayed.
-- @return bool True if overlay generation has started, false if generation is already in progress or an invalid overlay
type has been provided
function MapOverlayGenerator:generateSoilStateOverlay(finishedCallback, soilStateFilter)
    return self:generateOverlay(MapOverlayGenerator.OVERLAY_TYPE.SOIL, finishedCallback, soilStateFilter)
end


---Generate a farm land overlay.
-- @param function finishedCallback Called when generation is finished, signature: function(overlayId)
-- @param table mapPosition Map position vector of a selection position. If the position is within a farm land, it will
be highlighted.
function MapOverlayGenerator:generateFarmlandOverlay(finishedCallback, mapPosition)
    return self:generateOverlay(MapOverlayGenerator.OVERLAY_TYPE.FARMLANDS, finishedCallback, mapPosition)
end


---Check if any overlay is currently being generated and triggers a callback when it's finished.
function MapOverlayGenerator:checkOverlayFinished()
    if self.currentOverlayHandle ~= nil then
        if getIsDensityMapVisualizationOverlayReady(self.currentOverlayHandle) then
            self.overlayFinishedCallback(self.currentOverlayHandle)
            self.currentOverlayHandle = nil
        end
    end
end


---Reset overlay generation state.
function MapOverlayGenerator:reset()
    resetDensityMapVisualizationOverlay(self.foliageStateOverlay)
    resetDensityMapVisualizationOverlay(self.farmlandStateOverlay)
    resetDensityMapVisualizationOverlay(self.minimapOverlay)
    self.currentOverlayHandle = nil
end


---Update the state each frame.
Checks the overlay generation state.
function MapOverlayGenerator:update(dt)
    self:checkOverlayFinished()
end







---Get display information for crop types.
Override to add new crop types or change information.
-- @return Array of display information, {i={colors={true=[{r,g,b,a} colorblind], false=[{r,g,b,a} default], iconFilename=path,
iconUVs={u1, v1, u2, v2, u3, v3, u4, v4}, description=text, fruitTypeIndex=index}}
function MapOverlayGenerator:getDisplayCropTypes()
    local cropTypes = {}
    -- load crop type icon definitions in order of map configuration
    for _, fruitType in ipairs(self.missionFruitTypes) do
        if fruitType.shownOnMap then
            local fillableIndex = self.fruitTypeManager:getFillTypeIndexByFruitTypeIndex(fruitType.fruitTypeIndex)
            local fillable = self.fillTypeManager:getFillTypeByIndex(fillableIndex)

            local iconFilename = fillable.hudOverlayFilename
            local iconUVs = Overlay.DEFAULT_UVS -- default crop type icons are separate files, use full texture
            local description = fillable.title

            table.insert(cropTypes, {
                colors = {[false] = fruitType.defaultColor, [true] = fruitType.colorBlindColor},
                iconFilename = iconFilename,
                iconUVs = iconUVs,
                description = description,
                fruitTypeIndex = fruitType.fruitTypeIndex,
                foliageId = fruitType.foliageId
            })
        end
    end

    return cropTypes
end



---Get display information for growth states.
Growth states can be represented in multiple colors per state, so colors are defined in arrays per color blind mode.
Override to add new growth states or change information.
-- @return Array of display information, {i={colors={true={i={r,g,b,a}}, false={i={r,g,b,a}}}, description=text}}
function MapOverlayGenerator:getDisplayGrowthStates()
    local res = {
        -- indices are contiguous, so this definition is a valid array:
        [MapOverlayGenerator.GROWTH_STATE_INDEX.CULTIVATED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_CULTIVATED[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_CULTIVATED[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_CULTIVATED)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.STUBBLE_TILLAGE] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_STUBBLE_TILLAGE[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_STUBBLE_TILLAGE[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_STUBBLE_TILLAGE)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.SEEDBED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_SEEDBED[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_SEEDBED[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_SEEDBED)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.GROWING] = {
            colors = MapOverlayGenerator.FRUIT_COLORS_GROWING,
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_GROWING)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.HARVEST] = {
            colors = MapOverlayGenerator.FRUIT_COLORS_HARVEST,
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_HARVEST)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.HARVESTED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_CUT},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_CUT}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_HARVESTED)
        },
        [MapOverlayGenerator.GROWTH_STATE_INDEX.TOPPING] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_REMOVE_TOPS[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_REMOVE_TOPS[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_TOPPING)
        }
    }

    if not GS_IS_MOBILE_VERSION then
        res[MapOverlayGenerator.GROWTH_STATE_INDEX.PLOWED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_PLOWED[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_PLOWED[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_PLOWED)
        }

        res[MapOverlayGenerator.GROWTH_STATE_INDEX.WITHERED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_WITHERED[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_WITHERED[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.GROWTH_MAP_WITHERED)
        }
    end

    return res
end



---Get display information for soil states.
Soil states can be represented in multiple colors per state, so colors are defined in arrays per color blind mode.
Override to add new soil states or change information.
-- @return Array of display information, {i={colors={true={i={r,g,b,a}}, false={i={r,g,b,a}}}, description=text}}
function MapOverlayGenerator:getDisplaySoilStates()
    local fertilizerColors = {[true]={}, [false]={}}
    local mission = g_currentMission

    local maxFertilizerStates = mission.fieldGroundSystem:getMaxValue(FieldDensityMap.SPRAY_LEVEL)
    for colorBlind, colors in pairs(MapOverlayGenerator.FRUIT_COLORS_FERTILIZED) do
        for i=#colors, 1, -1 do
            local color = colors[i]
            table.insert(fertilizerColors[colorBlind], 1, color)

            if #fertilizerColors[colorBlind] == maxFertilizerStates then
                break
            end
        end
    end

    local res = {
        [MapOverlayGenerator.SOIL_STATE_INDEX.FERTILIZED] = {
            colors = fertilizerColors,
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.SOIL_MAP_FERTILIZED),
            isActive = true
        },
    }
    if not GS_IS_MOBILE_VERSION then
        res[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_LIME] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_LIME[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_LIME[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.SOIL_MAP_NEED_LIME),
            isActive = mission.missionInfo.limeRequired
        }

        res[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_PLOWING] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_PLOWING[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_PLOWING[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.SOIL_MAP_NEED_PLOWING),
            isActive = mission.missionInfo.plowingRequiredEnabled
        }

        res[MapOverlayGenerator.SOIL_STATE_INDEX.NEEDS_ROLLING] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_ROLLING[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_NEEDS_ROLLING[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.SOIL_MAP_NEED_ROLLING),
            isActive = true
        }

        res[MapOverlayGenerator.SOIL_STATE_INDEX.MULCHED] = {
            colors = {
                [true] = {MapOverlayGenerator.FRUIT_COLOR_MULCHED[true]},
                [false] = {MapOverlayGenerator.FRUIT_COLOR_MULCHED[false]}
            },
            description = self.l10n:getText(MapOverlayGenerator.L10N_SYMBOL.SOIL_MAP_MULCHED),
            isActive = true
        }
    end

    local weedSystem = mission.weedSystem
    if weedSystem ~= nil and weedSystem:getMapHasWeed() then
        local mapColor, mapColorBlind = weedSystem:getColors()
        local description = weedSystem:getTitle() or ""

        local colors = {[true]={}, [false]={}}
        for k, data in ipairs(mapColor) do
            table.insert(colors[true], mapColorBlind[k].color)
            table.insert(colors[false], data.color)
        end

        res[MapOverlayGenerator.SOIL_STATE_INDEX.WEEDS] = {
            colors = colors,
            description = description,
            isActive = mission.missionInfo.weedsEnabled
        }
    end

    local stoneSystem = mission.stoneSystem
    if stoneSystem ~= nil and stoneSystem:getMapHasStones() then
        local mapColor, mapColorBlind = stoneSystem:getColors()
        local description = stoneSystem:getTitle() or ""

        local colors = {[true]={}, [false]={}}
        for k, data in ipairs(mapColor) do
            table.insert(colors[true], mapColorBlind[k].color)
            table.insert(colors[false], data.color)
        end

        res[MapOverlayGenerator.SOIL_STATE_INDEX.STONES] = {
            colors = colors,
            description = description,
            isActive = mission.missionInfo.stonesEnabled
        }
    end

    return res
end
